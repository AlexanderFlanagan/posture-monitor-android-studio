package com.example.posture;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button goToPostureCheck;
    private Button goToImprovePosture;
    private Button viewImages;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        goToPostureCheck = findViewById(R.id.goToPostureCheck);
        goToPostureCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCheckPosture();
            }
        });
        goToImprovePosture = findViewById(R.id.goToImprovePosture);
        goToImprovePosture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImprovePosture();
            }
        });
        viewImages = findViewById(R.id.viewImages);
        viewImages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openViewImages();
            }
        });
    }
//go to check posture page
    private void openCheckPosture() {
        Intent intent = new Intent(this, checkPosture.class);
        startActivity(intent);
    }
    private void openImprovePosture(){
        Intent intent = new Intent(this, improvePosture.class);
        startActivity(intent);
    }
    private void openViewImages(){

    }
}
