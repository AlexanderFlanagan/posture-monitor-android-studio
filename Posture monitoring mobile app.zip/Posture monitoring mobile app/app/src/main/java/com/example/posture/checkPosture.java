package com.example.posture;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import static android.graphics.Color.RED;

public class checkPosture extends AppCompatActivity {

    private static final int CAPTURE_PERMISSION_CODE = 1000;
    private static final int PICK_PERMISSION_CODE = 1001;
    private static final int IMAGE_CAPTURE_CODE = 1002;
    private static final int IMAGE_PICK_CODE = 1003;
    private Button takePicture;
    private Button getPicture;
    private Button clearPosture;
    private ImageView postureImage;
    Uri image_uri;
    TextView neckAngle;
    TextView backAngle;
    TextView waistKneesAngle;
    TextView kneeFeetAngle;
    TextView totalAngle;
    int i = 0;
    private Float x;
    private Float y;
    public double angle;
    Float tempX1;
    Float tempX2;
    Float tempY1;
    Float tempY2;
    String tempText;
    private Canvas angleCanvas = new Canvas();
    private Paint anglePaint = new Paint();
    private Path anglePath = new Path();
    private Bitmap angleBitmap;
    //Drawable points = new BitmapDrawable(getResources(),angleBitmap);





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_posture);

        postureImage = findViewById(R.id.postureImage);
        takePicture = findViewById(R.id.takePicture);
        getPicture = findViewById(R.id.getPicture);
        clearPosture = findViewById(R.id.clearPosture);
        neckAngle = findViewById(R.id.neckAngle);
        backAngle = findViewById(R.id.backAngle);
        waistKneesAngle = findViewById(R.id.waistKneesAngle);
        kneeFeetAngle = findViewById(R.id.kneeFeetAngle);
        totalAngle = findViewById(R.id.totalAngle);
//        postureImage.setForeground(points);
//
//
//        angleBitmap = Bitmap.createBitmap(400,400,null);
//        angleCanvas.setBitmap(angleBitmap);
//        anglePaint.setStrokeWidth(20);
//        anglePaint.setColor(RED);
//        anglePaint.setStrokeCap(Paint.Cap.ROUND);
//        anglePaint.setStrokeJoin(Paint.Join.ROUND);
//        anglePaint.setStyle(Paint.Style.STROKE);


        postureImage.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                x = event.getX();
                y = event.getY();


                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        //anglePath.moveTo(x,y);
                        tempX1 = x;
                        tempY1 = y;

                        break;
                    case MotionEvent.ACTION_UP:
                        //anglePath.lineTo(x,y);
                        tempX2 = x;
                        tempY2 = y;
                        angle = Math.toDegrees(Math.atan2(tempY2 - tempY1, tempX2 - tempX1));
                        angle = angle - 90;
                        if (angle < 0){
                            angle = angle * -1;
                        }

                        i++;
                        if (i==1){
                            tempText = Double.toString(angle);
                            neckAngle.setText(tempText);
                        }
                        if(i==2){
                            tempText = Double.toString(angle);
                            backAngle.setText(tempText);

                        }
                        if(i==3){
                            tempText = Double.toString(angle);
                            waistKneesAngle.setText(tempText);

                        }
                        if(i==4){
                            tempText = Double.toString(angle);
                            kneeFeetAngle.setText(tempText);

                        }

                        if(i==5){
                            tempText = Double.toString(angle);
                            totalAngle.setText(tempText);
                        }
                        if(i>6){

                        }


                        break;
                    default:
                        return false;
                }
                //invalidate();


                return true;
            }
        });










        clearPosture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClearPosture();
            }
        });

        //takePicture button click
        takePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //request permission
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) ==
                            PackageManager.PERMISSION_DENIED ||
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_DENIED){
                        //permission not enabled then request it
                        String[] permission = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        // show pop up to request permission
                        requestPermissions(permission, CAPTURE_PERMISSION_CODE);
                    }
                    else {
                        //permission already granted
                        openCamera();

                    }

                }
                else {
                    openCamera();

                }
            }
        });


        //getPicture button click
        getPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check permission
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){
                        //permission not granted then request it
                        String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        //show popup for runtime permission
                        requestPermissions(permissions, PICK_PERMISSION_CODE);
                    }
                    else{
                        //permission already granted
                        pickImage();

                    }
                }
                else{
                    pickImage();


                }
            }
        });
    }



//    protected void onDraw(Canvas canvas){
//        angleCanvas.drawPath(anglePath, anglePaint);
//        canvas.drawBitmap(angleBitmap,0,0,null);
//        super.onDraw(canvas);
//
//    }




    public   void ClearPosture(){

        i = 0;

        neckAngle.setText("neck Angle");
        backAngle.setText("back Angle");
        waistKneesAngle.setText("waist knee Angle");
        kneeFeetAngle.setText("knee feet Angle");
        totalAngle.setText("Total angle Angle");

    }


    private void openCamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "new picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "from the camera");
        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        //camera intent
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(cameraIntent, IMAGE_CAPTURE_CODE);

    }

    private void pickImage(){
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_CODE);

    }

    //handling permission
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //called when user presses allow or deny permission for camera
        switch (requestCode) {
            case CAPTURE_PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED) {
                    //permission granted
                    openCamera();
                } else {
                    //permission denied
                    Toast.makeText(this, "permission was denied", Toast.LENGTH_SHORT).show();
                }
            }
            case PICK_PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED) {
                    //permission granted
                    pickImage();
                } else {
                    //permission denied
                    Toast.makeText(this, "permission was denied", Toast.LENGTH_SHORT).show();
                }

            }

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(resultCode == RESULT_OK && requestCode == IMAGE_CAPTURE_CODE){
            //set image captured to the image on the app page
            postureImage.setImageURI(image_uri);


        }
        if(resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE){
            //set image to image view
            postureImage.setImageURI(data.getData());
        }
    }
}


