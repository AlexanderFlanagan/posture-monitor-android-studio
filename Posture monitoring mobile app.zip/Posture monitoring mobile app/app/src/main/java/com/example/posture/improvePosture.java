package com.example.posture;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class improvePosture extends AppCompatActivity {
    private RecyclerView improvePostureRCView;
    private int[] images = {R.drawable.plank, R.drawable.bridge, R.drawable.back,R.drawable.thigh, R.drawable.hip};
    private String[] text = new String[]{"The plank – these targets lower back and core muscles. " +
            "The exercise is done by propping yourself up with your forearms and toes keeping legs straight and hips raised. " +
            "The NHS website recommends doing this for between five to ten seconds between eight to ten times. " +
            "This can help with slouching, leaning to far forward and a flat back.",
            "Bridges - this targets the buttocks and lower back. This is done by laying on your back with feet shoulder width apart. " +
                    "Then raise your hips so that they are inline with your knees and shoulders, repeated eight to ten times. " +
                    "This can help with slouching leaning to far forward and a flat back.",
            "Hold on tight back stretch – this is done by linking hands behind your back, pulling the shoulders back and sticking the upper chest out. " +
                    "Do this for eight to ten seconds, between eight to ten times. This can help with a hunched back and rounded shoulders",
            "Thigh stretch – grab your left ankle and bring it backwards towards your buttock keeping your knees together." +
                    " Avoid leaning towards one side and hold for fifteen seconds. This can help with forward leaning and the favouring of one side.",
            "Hip flexor stretches – put your left foot forward with both feet also facing forward." +
                    " Keeping your back leg straight and avoiding arching the back slowly bend your front leg and push your hips forward. " +
                    "Do this and hold for fifteen seconds then repeat on the other leg. This can help with forward leaning and the favouring of one side."};
    private RecyclerAdaptor adaptor;
    private RecyclerView.LayoutManager layoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_improve_posture);
        improvePostureRCView = findViewById(R.id.improvePostureRCView);
        layoutManager = new GridLayoutManager(this, 1);
        improvePostureRCView.setHasFixedSize(true);
        improvePostureRCView.setLayoutManager(layoutManager);
        adaptor = new RecyclerAdaptor(images,text);
        improvePostureRCView.setAdapter(adaptor);
    }
}
