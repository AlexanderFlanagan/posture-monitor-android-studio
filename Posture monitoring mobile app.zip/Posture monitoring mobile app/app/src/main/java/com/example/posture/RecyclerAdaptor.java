package com.example.posture;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerAdaptor extends RecyclerView.Adapter<RecyclerAdaptor.ImageViewHolder> {

    private int[] images;
    private String[] text;

    public RecyclerAdaptor(int[] images, String[] text){
        this.images = images;
        this.text = text;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.improve_posture_layout,parent,false);
        ImageViewHolder imageViewHolder = new ImageViewHolder(view);
        return imageViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        int image_id = images[position];
        String text_id = text[position];
        holder.Exsersie.setImageResource(image_id);
        holder.exsersiseDescription.setText(text_id);

    }

    @Override
    public int getItemCount() {
        return images.length;
    }
    public static class ImageViewHolder extends RecyclerView.ViewHolder {
        ImageView Exsersie;
        TextView exsersiseDescription;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            Exsersie = itemView.findViewById(R.id.exsersise);
            exsersiseDescription = itemView.findViewById(R.id.description);
        }
    }
}
